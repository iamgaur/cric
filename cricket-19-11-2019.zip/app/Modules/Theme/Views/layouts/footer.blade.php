<footer class="footer">
	<div class="container-fluid">
		<p class="copyright pull-right">
			&copy; {{ date('Y') }} </p>
	</div>
</footer>