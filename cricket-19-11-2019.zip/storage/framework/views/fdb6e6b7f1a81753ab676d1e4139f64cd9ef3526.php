
    <?php $__env->startSection('content'); ?>
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Match Team Squad</h4>
                            </div>
                            <div class="content table-responsive table-full-width">
                                <table class="table table-hover table-striped">
                                    <thead>
                                         <tr>
                                            <th>Match ID</th>
                                            <th>First Team</th>
                                            <th>Second Team</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $fetchMatchSquads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($value['match_id']); ?></td>
                                                <td><?php echo e($value['firstTeam_name']); ?></td>
                                                <td><?php echo e($value['secondTeam_name']); ?></td>
                                                <td>
                                                    <a href="<?php echo e(route('editMatchSquad', ['slug' => $value['slug']])); ?>">edit</a> |
                                                    <a href="<?php echo e(route('deleteMatchSquad', ['slug' => $value['slug']])); ?>" onclick="if (!confirm('are you sure want to delete this match?')) return false;" >delete</a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('Theme::layouts.baseLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nkrjm0cj9ho1/public_html/demo2.pricecheckindia.in/app/Modules/MatchSquad/Views/index.blade.php ENDPATH**/ ?>