    <?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="header">
                            <h4 class="title"><?php echo e($title); ?></h4>
                            <a class="linkClass" href=" <?php echo e(route('teams')); ?>">Back to list</a>
                        </div>
                        <div class="content">
                            <form method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>Name</label>
                                            <input type="text" class="form-control" placeholder="Team name" value="<?php echo e(old('name', $team->name)); ?>" name="name" id="team_name">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>Short name</label>
                                            <input type="text" class="form-control" placeholder="Short name" value="<?php echo e(old('short_name', $team->short_name)); ?>" name="short_name" id="short_name">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>Country</label>
                                            <select class="form-control" name="country_id" id="team_country">
                                                <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country_id => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                   <option <?php echo e(old('country_id', $team->country_id) == $country_id ? 'selected' : null); ?> value="<?php echo e($country_id); ?>"><?php echo e($name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>Type</label>
                                            <select class="form-control" name="team_type" id="team_type">
                                              <?php $__currentLoopData = $teamType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type_id => $type_value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                              <option <?php echo e(old('country_id', $team->team_type) == $type_id ? 'selected' : null); ?> value="<?php echo e($type_id); ?>"><?php echo e($type_value); ?></option>
                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>Meta title</label>
                                            <input type="text" class="form-control" placeholder="Meta title" name="meta_title" value="<?php echo e(old('meta_title', $team->meta_title)); ?>" id="meta_title">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>Meta description</label>
                                            <input type="text" class="form-control" placeholder="Meta description" name="meta_description" value="<?php echo e(old('meta_description', $team->meta_description)); ?>" id="meta_description">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>Meta keywords</label>
                                            <input type="text" class="form-control" placeholder="Meta keywords" name="meta_keywords" value="<?php echo e(old('meta_keywords', $team->meta_keywords)); ?>" id="meta_keywords">
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                          <input type="file" id="file1" class="form-control" value="<?php echo e(old('image', $team->image)); ?>" name="image" accept="image/*">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>Alt Tag</label>
                                            <input type="text" class="form-control" value="<?php echo e(old('alt_tag', $team->alt_tag)); ?>" placeholder="Image Alt Tag" name="alt_tag" id="alt_tag">
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>Image Title</label>
                                            <input type="text" class="form-control" value="<?php echo e(old('image_title', $team->image_title)); ?>" placeholder="Image Alt Tag" name="image_title" id="image_title">
                                        </div>
                                    </div>
                                </div>


                                <input type="submit" class="btn btn-info btn-fill pull-right" />
                                <div class="clearfix"></div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('Theme::layouts.baseLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nkrjm0cj9ho1/public_html/demo2.pricecheckindia.in/app/Modules/Team/Views/add.blade.php ENDPATH**/ ?>