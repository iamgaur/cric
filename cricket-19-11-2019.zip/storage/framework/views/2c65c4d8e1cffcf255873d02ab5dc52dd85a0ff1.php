<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="header">
                        <h4 class="title"><?php echo e($dataArray['series_name']); ?></h4>
                    </div>
                    <div class="content table-responsive table-full-width">
                      <form  method="post">
                            <?php echo csrf_field(); ?>
                        <table class="table table-hover table-striped">
                            <thead>
                                <tr><th>Team</th>
                                    <th>Played</th>
                                    <th>Won</th>
                                    <th>Lost</th>
                                    <th>Tied</th>
                                    <th>NR</th>
                                    <th>Points</th>
                                    <th>NRR</th>
                                </tr></thead>
                            <tbody>
                                  <?php $__currentLoopData = $dataArray['teams']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team_id => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <?php
                                  if(isset($dataArray['points']) && !empty($dataArray['points']) && isset($dataArray['points'][$team_id])) {
                                    $points = json_decode($dataArray['points'][$team_id],true);
                                  } else {
                                    $points = array();
                                  }
                                  ?>
                                  <tr>
                                    <td><?php echo e($name); ?></td>
                                    <td><input style="width:70px" type="number"  value="<?php echo e(isset($points['tp']) ? $points['tp'] : 0); ?>" name="tp[<?php echo e($team_id); ?>]"></td>
                                    <td><input style="width:70px" type="number"  value="<?php echo e(isset($points['won']) ? $points['won'] : 0); ?>" name="won[<?php echo e($team_id); ?>]"></td>
                                    <td><input style="width:70px" type="number"  value="<?php echo e(isset($points['lost']) ? $points['lost'] : 0); ?>" name="lost[<?php echo e($team_id); ?>]"></td>
                                    <td><input style="width:70px" type="number"  value="<?php echo e(isset($points['tied']) ? $points['tied'] : 0); ?>" name="tied[<?php echo e($team_id); ?>]"></td>
                                    <td><input style="width:70px" type="number"  value="<?php echo e(isset($points['nr']) ? $points['nr'] : 0); ?>" name="nr[<?php echo e($team_id); ?>]"></td>
                                    <td><input style="width:70px" type="number"  value="<?php echo e(isset($points['pts']) ? $points['pts'] : 0); ?>" name="pts[<?php echo e($team_id); ?>]"></td>
                                    <td><input style="width:70px" type="number"  value="<?php echo e(isset($points['nrr']) ? $points['nrr'] : 0); ?>" name="nrr[<?php echo e($team_id); ?>]"></td>
                                  </tr>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  <input type="hidden" value="<?php echo e(implode(",",array_keys($dataArray['teams']))); ?>" name="teams"/>
                                  <input type="hidden" value="<?php echo e($dataArray['series_id']); ?>" name="series_id"/>
                              </tbody>
                              </table>
                              <input type="submit" class="btn btn-info btn-fill pull-right" />
                              <div class="clearfix"></div>
                              </form>

                    </div>
                </div>
            </div>

        </div>
    </div>
</div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('Theme::layouts.baseLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nkrjm0cj9ho1/public_html/demo2.pricecheckindia.in/app/Modules/Series/Views/point_table.blade.php ENDPATH**/ ?>