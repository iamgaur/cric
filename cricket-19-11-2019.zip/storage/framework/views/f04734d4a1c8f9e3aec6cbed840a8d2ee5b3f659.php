
    <?php $__env->startSection('content'); ?>
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="header">
                                <h4 class="title"><?php echo e($title); ?></h4>
                                <a class="linkClass" href="<?php echo e(route('matchTeams')); ?>">Back to list</a>
                            </div>
                            <div class="content">
                                <form method="post">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Match ID</label>
                                                <input type="text" class="form-control" placeholder="Match ID" value="<?php echo e(old('match_id', $matchTeams->match_id)); ?>" name="match_id" id="match_id">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>First Team</label>
                                                <select class="form-control" name="first_team" id="first_team">
                                                    <option>Select First Team</option>
                                                        <?php $__currentLoopData = $teamList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option <?php echo e(old('first_team', $matchTeams->first_team) == $id ? 'selected': null); ?>  value="<?php echo e($id); ?>"><?php echo e($name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Second Team</label>
                                                <select class="form-control" name="second_team" id="second_team">
                                                    <option>Select Second Team</option>
                                                        <?php $__currentLoopData = $teamList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                                            <option <?php echo e(old('second_team', $matchTeams->second_team) == $id ? 'selected': null); ?> value="<?php echo e($id); ?>"><?php echo e($name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <input type="submit" class="btn btn-info btn-fill pull-right" />
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('Theme::layouts.baseLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nkrjm0cj9ho1/public_html/demo2.pricecheckindia.in/app/Modules/MatchTeams/Views/add.blade.php ENDPATH**/ ?>