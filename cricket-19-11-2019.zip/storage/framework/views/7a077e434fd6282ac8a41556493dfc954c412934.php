
<?php $__env->startSection('content'); ?>

<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="header">
                        <h4 class="title"><?php echo e($title); ?></h4>
                        <a class="linkClass" href="<?php echo e(route('gallery')); ?>">Back to list</a>
                    </div>
                    <div class="content">
                        <form  method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-12">
                                    <label>Select gallery type for:</label>
                                    <div class="form-group">
                                        <?php $__currentLoopData = config('constants.gallery_type'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <label class="radio-inline">
                                                <input class="gallery-type" type="radio" value="<?php echo e($value); ?>" name="type" <?php echo e((old('type', $opted) == $value) ? 'checked' : null); ?>><?php echo e($key); ?>

                                            </label>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                            <?php $__currentLoopData = config('constants.gallery_type'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="row item_id <?php echo e((old('type', $opted) != $value) ? 'hidden': null); ?>" id="<?php echo e($value); ?>">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="<?php echo e($key); ?>">Select <?php echo e($key); ?>:</label>
                                            <select name="item_id[<?php echo e($value); ?>]" class="form-control" id="<?php echo e($key); ?>">
                                                <option value="">Select <?php echo e($key); ?></option>
                                                <?php $__currentLoopData = $gallery_types[strtolower($key)]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option <?php echo e(old('item_id.'. $value, $gallery->item_id) == $id ? 'selected' : null); ?> value=<?php echo e($id); ?>><?php echo e($name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Gallery Title</label>
                                        <input type="text" class="form-control" value="<?php echo e(old('alt_tag', $gallery->gallery_title)); ?>" placeholder="Gallery Title" name="gallery_title" id="gallery_title">
                                    </div>
                                </div>
                            </div>


                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Embed Code</label>
                                        <textarea rows="7" class="form-control" placeholder="Embed Code" name="embed_code" id="embed_code"><?php echo e(old('embed_code', $gallery->embed_code)); ?></textarea>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Gallery Description</label>
                                        <textarea rows="7" class="form-control" placeholder="Gallery Description" name="gallery_description" id="gallery_description"><?php echo e(old('gallery_description', $gallery->gallery_description)); ?></textarea>
                                    </div>
                                </div>
                            </div>


                            <input type="submit" class="btn btn-info btn-fill pull-right" />
                            <div class="clearfix"></div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.lazyload/1.9.1/jquery.lazyload.min.js" type="text/javascript"></script>
<script>
    $(function () {
        $(document.body).on('click', '.gallery-type', function() {
            $('.item_id').addClass('hidden');
            $('#' + $(this).val()).removeClass('hidden');
        });
    });

    $(document).ready(function(){
    	var i=1;
    	$('#add').click(function(){
    		 i++;
    		 $('#dynamic_field').append('<tr id="row'+i+'" class="dynamic-added"><td><input type="file" name="image[]" placeholder="Please select image" class="custom-file-input" id="inputGroupFile02" /></td><td><button type="button" name="remove" id="'+i+'" class="btn btn-danger btn_remove">X</button></td></tr>');
    	 });
    	 $(document).on('click', '.btn_remove', function(){
    		 var button_id = $(this).attr("id");
    		 $('#row'+button_id+'').remove();
    	 });
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('Theme::layouts.baseLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nkrjm0cj9ho1/public_html/demo2.pricecheckindia.in/app/Modules/Gallery/Views/add.blade.php ENDPATH**/ ?>