<?php if($errors->has('message')): ?>
    <div class="col-xl-12 col-md-12 alert alert-danger alert-dismissible">
      <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
       <strong><?php echo e($errors->first('message')); ?></strong>
    </div> 
<?php elseif($errors->all()): ?>
    <?php $__currentLoopData = $errors->getMessages(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-xl-12 col-md-12 alert alert-danger alert-dismissible">
          <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
           <strong><?php echo e($errors->first($key)); ?></strong>
        </div>
        <?php break; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?><?php /**PATH /home/nkrjm0cj9ho1/public_html/demo2.pricecheckindia.in/app/Modules/Theme/Views/layouts/errors.blade.php ENDPATH**/ ?>