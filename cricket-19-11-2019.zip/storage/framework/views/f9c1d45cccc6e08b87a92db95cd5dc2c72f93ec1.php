    <?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="header">
                            <h4 class="title">Players</h4>
                            <a class="linkClass" href="<?php echo e(route('addPlayer')); ?>">Add new player</a> | 
                            <a class="linkClass" href="<?php echo e(route('groupFields')); ?>">Add Global Field Group</a>
                        </div>
                        <div class="content table-responsive table-full-width">
                            <table class="table table-hover table-striped">
                                <thead>
                                    <tr><th>ID</th>
                                        <th>Name</th>
                                        <th>Action</th>
                                    </tr></thead>
                                <tbody>
                                    <?php $__currentLoopData = $fetchPlayer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($value['pid']); ?></td>
                                            <td><?php echo e($value['player_name']); ?></td>
                                            <td><a href="<?php echo e(route('editPlayer', ['p_slug' => $value['p_slug'], 'c_slug' => $value['c_slug'] ])); ?>">edit</a> |
                                                <a href="<?php echo e(route('deletePlayer', ['id' => $value['pid']])); ?>" onclick="if (!confirm('are you sure want to delete this player?')) return false;" >delete</a>
                                            </td>
                                         </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>

                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('Theme::layouts.baseLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nkrjm0cj9ho1/public_html/demo2.pricecheckindia.in/app/Modules/Player/Views/index.blade.php ENDPATH**/ ?>