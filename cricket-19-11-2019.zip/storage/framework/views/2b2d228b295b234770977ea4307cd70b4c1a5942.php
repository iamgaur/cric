<?php $__env->startSection('content'); ?>

<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="header">
                        <h4 class="title"><?php echo e($title); ?></h4>
                        <a class="linkClass" href="<?php echo e(route('iccRanking')); ?>">Back to list</a>
                    </div>
                    <div class="content">
                        <form  method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-12">
                                    <label>Select Icc Ranking type for:</label>
                                    <div class="form-group">
                                        <?php $__currentLoopData = config('constants.ranking_type'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <label class="radio-inline">
                                                <input class="ranking-type" type="radio" value="<?php echo e($value); ?>" name="ranking_type" <?php echo e((old('ranking_type', $opted) == $value) ? 'checked' : null); ?>><?php echo e($key); ?>

                                            </label>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <label>Select Gender:</label>
                                    <div class="form-group">
                                        <?php $__currentLoopData = config('constants.gender'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <label class="radio-inline">
                                                <input class="gender-type" type="radio" value="<?php echo e($key); ?>" name="gender" <?php echo e((old('gender', $optedGender) == $key) ? 'checked' : null); ?>><?php echo e($value); ?>

                                            </label>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                            <?php $__currentLoopData = config('constants.ranking_type'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="row item_id <?php echo e((old('ranking_type', $opted) != $value) ? 'hidden': null); ?>" id="<?php echo e($value); ?>">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="<?php echo e($key); ?>">Select <?php echo e($key); ?>:</label>
                                            <select name="item_id[<?php echo e($value); ?>]" class="form-control" id="<?php echo e($key); ?>">
                                                <option value="">Select <?php echo e($key); ?></option>
                                                <?php $__currentLoopData = $rankingTypes[strtolower($key)]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option <?php echo e(old('item_id.'. $value, $iccRanking->item_id) == $id ? 'selected' : null); ?> value=<?php echo e($id); ?>><?php echo e($name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div> 
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="row team category">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>T20 RATING</label>
                                        <input type="number" class="form-control" placeholder="T20 Rating" value="<?php echo e(old('t20_rating', $iccRanking->t20_rating )); ?>" name="t20_rating" id="t20_rating">
                                    </div>
                                </div>
                            </div>
                            <div class="row team category">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>ODI RATING</label>
                                        <input type="number" class="form-control" placeholder="ODI Rating" value="<?php echo e(old('odi_rating', $iccRanking->odi_rating )); ?>" name="odi_rating" id="odi_rating">
                                    </div>
                                </div>
                            </div>
                            <div class="row team category">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>TEST RATING</label>
                                        <input type="number" class="form-control" placeholder="TEST Rating" value="<?php echo e(old('test_rating', $iccRanking->test_rating )); ?>" name="test_rating" id="test_ranking">
                                    </div>
                                </div>
                            </div>
                            <div class="row player category">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>T20 BATING RATING</label>
                                        <input type="number" class="form-control" placeholder="T20 BATING RATING" value="<?php echo e(old('t20_batting_rating', $iccRanking->t20_batting_rating )); ?>" name="t20_batting_rating" id="t20_batting_rating">
                                    </div>
                                </div>
                            </div>
                            <div class="row player category">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>T20 BOWLING RATING</label>
                                        <input type="number" class="form-control" placeholder="T20 BOWLING RATING" name="t20_bowling_rating" value="<?php echo e(old('odi_bowling_rating', $iccRanking->t20_bowling_rating )); ?>" id="t20_bowling_rating">
                                    </div>
                                </div>
                            </div>
                            <div class="row player category">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>T20 ALL ROUNDER RATING</label>
                                        <input type="number" class="form-control" placeholder="T20 ALL ROUNDER RATING" value="<?php echo e(old('t20_all_rounder_rating', $iccRanking->t20_all_rounder_rating)); ?>" name="t20_all_rounder_rating" id="t20_all_rounder_rating">
                                    </div>
                                </div>
                            </div>
                             <div class="row player category">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>ODI BATING RATING</label>
                                        <input type="number" class="form-control" placeholder="ODI BATING RATING" value="<?php echo e(old('odi_batting_rating', $iccRanking->odi_batting_rating )); ?>" name="odi_batting_rating" id="odi_batting_rating">
                                    </div>
                                </div>
                            </div>
                            <div class="row player category">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>ODI BOWLING RATING</label>
                                        <input type="number" class="form-control" placeholder="ODI BOWLING RATING" name="odi_bowling_rating" value="<?php echo e(old('odi_bowling_rating', $iccRanking->odi_bowling_rating )); ?>" id="odi_bowling_ranking">
                                    </div>
                                </div>
                            </div>
                            <div class="row player category">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>ODI ALL ROUNDER RATING</label>
                                        <input type="number" class="form-control" placeholder="ODI ALL ROUNDER RATING" value="<?php echo e(old('odi_all_rounder_rating', $iccRanking->odi_all_rounder_rating)); ?>" name="odi_all_rounder_rating" id="odi_all_rounder_rating">
                                    </div>
                                </div>
                            </div>
                             <div class="row player category">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>TEST BATING RATING</label>
                                        <input type="number" class="form-control" placeholder="TEST BATING RATING" value="<?php echo e(old('test_batting_rating', $iccRanking->test_batting_rating )); ?>" name="test_batting_rating" id="test_batting_rtking">
                                    </div>
                                </div>
                            </div>
                            <div class="row player category">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>TEST BOWLING RATING</label>
                                        <input type="number" class="form-control" placeholder="TEST BOWLING RATING" name="test_bowling_rating" value="<?php echo e(old('test_bowling_rating', $iccRanking->test_bowling_rating )); ?>" id="test_bowling_rating">
                                    </div>
                                </div>
                            </div>
                            <div class="row player category">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>TEST ALL ROUNDER RATING</label>
                                        <input type="number" class="form-control" placeholder="TEST ALL ROUNDER RATING" value="<?php echo e(old('test_all_rounder_rating', $iccRanking->test_all_rounder_rating)); ?>" name="test_all_rounder_rating" id="test_all_rounder_rating">
                                    </div>
                                </div>
                            </div>
                            <input type="submit" class="btn btn-info btn-fill pull-right" />
                            <div class="clearfix"></div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script>
    $(function () {
        var category = getCategory($('.ranking-type:checked').val());
        $('.category').addClass('hidden');
        $('.' + category).removeClass('hidden');
        $(document.body).on('click', '.ranking-type', function() {
            var category = getCategory($(this).val());
            $('.item_id, .category').addClass('hidden');
            $('#' + $(this).val() + ', .' + category).removeClass('hidden');
        });
    });

    function getCategory(swtichTo) {
        var category = 'empty';
        switch(swtichTo) {
               case '1':
                   category = 'team';
                   break;
               case '2':
                   category = 'player';
                   break;
        }
        return category;
    }
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('Theme::layouts.baseLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nkrjm0cj9ho1/public_html/demo2.pricecheckindia.in/app/Modules/IccRanking/Views/add.blade.php ENDPATH**/ ?>