    <?php $__env->startSection('content'); ?>
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Matches</h4><a class="linkClass" href="<?php echo e(route('addMatch')); ?>">Add new match</a> | 
                                <a class="linkClass" href="<?php echo e(route('matchGroupFields')); ?>">Add Global Field Group</a>
                            </div>
                            <div class="content table-responsive table-full-width">
                                <table class="table table-hover table-striped">
                                    <thead>
                                        <tr><th>Match ID</th>
                                            <th>Series ID</th>
                                            <th>Between</th>
                                            <th>Date</th>
                                            <th>Action</th>
                                        </tr></thead>
                                    <tbody>
                                        
                                        <?php $__currentLoopData = $fetchMatches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($value['id']); ?></td>
                                                <td><?php echo e($value['series']['name']); ?></td>
                                                <td><?php echo e($value['match_title']); ?></td>
                                                <td><?php echo e(date('Y-m-d', strtotime($value['match_date']))); ?></td>
                                                <td><a href="<?php echo e(route('editMatch', ['slug' => $value['slug']])); ?>">edit</a> |
                                                    <a href="<?php echo e(route('deleteMatch', ['slug' => $value['slug']])); ?>" onclick="if (!confirm('are you sure want to delete this match?')) return false;" >delete</a></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('Theme::layouts.baseLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nkrjm0cj9ho1/public_html/demo2.pricecheckindia.in/app/Modules/Match/Views/index.blade.php ENDPATH**/ ?>