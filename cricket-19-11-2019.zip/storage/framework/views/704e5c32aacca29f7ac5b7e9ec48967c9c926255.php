<style>
    .btn-green {
        background-color: yellow !important;
        color: black !important;
    }
</style>
<?php $__env->startSection('content'); ?>
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="header">
                                <h4 class="title"><?php echo e($title); ?></h4><a class="linkClass" href="<?php echo e(route('addGallery')); ?>">Add new gallery</a> &nbsp | &nbsp
                                <a class="linkClass" href="<?php echo e(route('addgalleryphoto')); ?>">Add photos</a>
                            </div>
                            <div class="content table-responsive table-full-width">
                              <?php
                              $k = 1;
                              ?>

                                <table class="table table-hover table-striped">
                                    <thead>
                                        <tr><th>S.No.</th>
                                            <th>Image title</th>
                                            <th>Alt tag</th>
                                            <th>Image description</th>
                                            <th>Image</th>
                                            <th>Profile Image</th>
                                            <th> Action </th>
                                            <?php if(isset($allGallery)): ?>
                                            <th>Associate</th>
                                            <?php endif; ?>
                                        </tr></thead>
                                    <tbody>

                                    <?php $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gal_info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <tr class="image-row" data-photo-id="<?php echo e($gal_info['id']); ?>">
                                          <td> <?php echo e($k++); ?> </td>
                                          <td> <?php echo e($gal_info['image_title']); ?> </td>
                                          <td> <?php echo e($gal_info['alt_tag']); ?> </td>
                                          <td> <?php echo e($gal_info['image_description']); ?> </td>
                                          <td> <img src="<?php echo e(URL::to('/images/gallery/') .'/'.$gal_info['image']); ?>" border="0" width="40" height="40"/> </td>
                                          <td> <?php echo e(!empty($gal_info['profile_pic']) ? 'Yes' : 'No'); ?> </td>
                                          <td><a href="<?php echo e(route('editPhoto', ['id' => $gal_info['id']])); ?>">Profile Pic</a> |
                                              <a href="<?php echo e(route('deletePhoto', ['id' => $gal_info['id']])); ?>" onclick="if (!confirm('are you sure want to delete this Photo?')) return false;" >delete</a> </td>
                                          <?php if(isset($allGallery)): ?>
                                          <td><button type="button" class="btn btn-fill btn-sm associate-photo" data-toggle="modal" data-target="#associateGalleryModal">Associate photo</button>
                                          </td>
                                          <?php endif; ?>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                        
                                       <?php $__currentLoopData = $associativeGalleryPhotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gal_info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <tr class="associated-row">
                                          <td> <?php echo e($k++); ?> </td>
                                          <td> <?php echo e($gal_info['image_title']); ?> </td>
                                          <td> <?php echo e($gal_info['alt_tag']); ?> </td>
                                          <td> <?php echo e($gal_info['image_description']); ?> </td>
                                          <td> <img src="<?php echo e(URL::to('/images/gallery/') .'/'.$gal_info['image']); ?>" border="0" width="40" height="40"/> </td>
                                          <td> <?php echo e(!empty($gal_info['profile_pic']) ? 'Yes' : 'No'); ?> </td>
                                          <td><a onclick="if (!confirm('are you sure want to de-associate this Photo?')) return false;"
                                                  href="<?php echo e(route('deAssociatePhoto',['associative_id' => $parentGallery['id'], 'photo_id' => $gal_info['id']])); ?>" >De-associate</a></td>
                                          <td><button type="button" class="btn btn-green btn-sm associated-pic">Associated photo</button>
                                          </td>               
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>

                            </div>
                            
                        </div>
                    </div>

                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>
    <?php echo $__env->make('Gallery::associateGallery', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startPush('scripts'); ?>
<script>
    $(function() {
        $('.associate-photo').on('click', function () {
            var photo_id = $(this).parents('tr').attr('data-photo-id');
            $('#associateGalleryModal .photo-id').val(photo_id);
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('Theme::layouts.baseLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nkrjm0cj9ho1/public_html/demo2.pricecheckindia.in/app/Modules/Gallery/Views/getPhotos.blade.php ENDPATH**/ ?>