    <?php $__env->startSection('content'); ?>
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Teams</h4><a class="linkClass" href="<?php echo e(route('addTeam')); ?>">Add new team</a> &nbsp | &nbsp
                                <a class="linkClass" href="<?php echo e(route('getType')); ?>">Add new type</a>
                            </div>
                            <?php if(count($teamType)): ?>
                            <div class="content table-responsive table-full-width">
                                <table class="table table-hover table-striped">
                                    <thead>
                                        <tr><th>ID</th>
                                            <th>Type Name</th>
                                        </tr></thead>
                                    <tbody>
                                       <?php $__currentLoopData = $teamType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <tr>
                                              <td><?php echo e($key); ?></td>
                                              <td><?php echo e($value); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <?php endif; ?>
                            <div class="content">
                                <form method="post">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Name</label>
                                                <input type="text" class="form-control" placeholder="Team Type name" name="name">
                                            </div>
                                        </div>
                                    </div>

                                    <input type="submit"  class="btn btn-info btn-fill pull-right" />
                                    <div class="clearfix"></div>
                                </form>
                            </div>


                        </div>
                    </div>

                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('Theme::layouts.baseLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nkrjm0cj9ho1/public_html/demo2.pricecheckindia.in/app/Modules/Team/Views/teamType.blade.php ENDPATH**/ ?>