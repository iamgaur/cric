<footer class="footer">
	<div class="container-fluid">
		<p class="copyright pull-right">
			&copy; <?php echo e(date('Y')); ?> </p>
	</div>
</footer><?php /**PATH /home/nkrjm0cj9ho1/public_html/demo2.pricecheckindia.in/app/Modules/Theme/Views/layouts/footer.blade.php ENDPATH**/ ?>