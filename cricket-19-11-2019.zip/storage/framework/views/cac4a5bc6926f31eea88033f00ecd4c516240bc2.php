<?php
    $currentRouteName = strlen(Route::currentRouteName()) ? Route::currentRouteName() : null;
?>

<ul class="nav">
	<li class="<?php echo e(($currentRouteName == 'dashboard') ? 'active' : ''); ?>">
		<a href="<?php echo e(route('dashboard')); ?>">
			<i class="pe-7s-graph"></i>
			<p>Dashboard</p>
		</a>
	</li>
	<li class="<?php echo e(in_array($currentRouteName, ['countries', 'addCountry', 'editCountry']) ? 'active' : ''); ?>">
		<a href="<?php echo e(route('countries')); ?>">
			<p>Country</p>
		</a>
	</li>
	<li class="<?php echo e(in_array($currentRouteName, ['teams', 'addTeam','editTeam']) ? 'active' : ''); ?>">
		<a href="<?php echo e(route('teams')); ?>">
			<p>Team</p>
		</a>
	</li>
	<li class="<?php echo e(in_array($currentRouteName, ['series', 'addSeries', 'editSeries']) ? 'active' : ''); ?>">
		<a href="<?php echo e(route('series')); ?>">
			<p>Series</p>
		</a>
	</li>
	<li class="<?php echo e(in_array($currentRouteName, ['seriesSquads', 'addSeries', 'editSeries']) ? 'active' : ''); ?>">
		<a href="<?php echo e(route('seriesSquads')); ?>">
			<p>Series Squads</p>
		</a>
	</li>
	<li class="<?php echo e(in_array($currentRouteName, ['matches', 'addMatch', 'editMatch']) ? 'active' : ''); ?>">
		<a href="<?php echo e(route('matches')); ?>">
			<p>Match</p>
		</a>
	</li>
        <li class="<?php echo e(in_array($currentRouteName, ['matchTeams', 'addMatchTeams', 'editMatchTeams']) ? 'active' : ''); ?>">
            <a href="<?php echo e(route('matchTeams')); ?>">
                <p>Match -- Teams</p>
            </a>
        </li>
        <li class="<?php echo e(in_array($currentRouteName, ['matchSquads', 'editMatchSquad']) ? 'active' : ''); ?>">
            <a href="<?php echo e(route('matchSquads')); ?>">
                <p>Match -- Squad</p>
            </a>
        </li>
	<li class="<?php echo e(in_array($currentRouteName, ['players', 'addPlayer', 'editPlayer']) ? 'active' : ''); ?>">
		<a href="<?php echo e(route('players')); ?>">
			<p>Player</p>
		</a>
	</li>
	<li class="<?php echo e(in_array($currentRouteName, ['iccRanking', 'addIccRanking', 'editIccRanking']) ? 'active' : ''); ?>">
		<a href="<?php echo e(route('iccRanking')); ?>">
			<p>Icc Ranking</p>
		</a>
	</li>
	<li class="<?php echo e(in_array($currentRouteName, ['news', 'addNews', 'editNews']) ? 'active' : ''); ?>">
		<a href="<?php echo e(route('news')); ?>">
			<p>News</p>
		</a>
	</li>
	<li class="<?php echo e(in_array($currentRouteName, ['gallery', 'addGallery', 'editGallery']) ? 'active' : ''); ?>">
		<a href="<?php echo e(route('gallery')); ?>">
			<p>Gallery</p>
		</a>
	</li>
	<li class="<?php echo e(($currentRouteName == 'logout') ? 'active' : ''); ?>">
		<a href="<?php echo e(route('logout')); ?>">
			<p>Logout</p>
		</a>
	</li>

</ul><?php /**PATH /home/nkrjm0cj9ho1/public_html/demo2.pricecheckindia.in/app/Modules/Theme/Views/layouts/menu.blade.php ENDPATH**/ ?>