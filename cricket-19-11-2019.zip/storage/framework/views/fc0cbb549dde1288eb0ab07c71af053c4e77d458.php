<style>
    .text-color-white {
        color: white !important;
    }
</style>

<!-- Modal -->
<div id="associateGalleryModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Associate this photo with Gallery</h4>
      </div>
      <div class="modal-body">
          <form action="<?php echo e(route('postAssociteGallery')); ?>" method='post'>
            <label>Select Gallery</label>
            <select class="form-control" name="associative_id" id="g_id">
                <option value="">Select Gallery</option>
                <?php $__currentLoopData = $allGallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g_id => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <?php if($g_id !== $parentGallery['id']): ?>
                        <option <?php echo e((old('g_id') == $g_id) ? 'selected' : null); ?> value="<?php echo e($g_id); ?>"><?php echo e($value); ?></option>
                    <?php endif; ?>    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <br>
            <?php echo csrf_field(); ?>
            <input type="hidden" class="photo-id" name="photo_id">
            <input type="hidden" class="gallery-id" name="g_id" value="<?php echo e(@reset($gallery)['id']); ?>">
            <input type="submit" class="btn btn-info text-color-white" value="Save">
          </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
<?php $__env->startPush('scripts'); ?>
<script>
$(function () {
        $('#associateGalleryModal').on('hidden.bs.modal', function () {
            $('.photo-id', this).val('');
        });
    });
</script>
<?php $__env->stopPush(); ?><?php /**PATH /home/nkrjm0cj9ho1/public_html/demo2.pricecheckindia.in/app/Modules/Gallery/Views/associateGallery.blade.php ENDPATH**/ ?>