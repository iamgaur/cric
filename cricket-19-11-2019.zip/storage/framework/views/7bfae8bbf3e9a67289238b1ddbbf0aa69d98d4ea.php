<?php if(session()->has('success')): ?>
    <div class="col-xl-12 col-md-12 alert alert-success alert-dismissible">
      <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
       <strong><?php echo e(session()->get('success')); ?></strong>
    </div>
<?php endif; ?><?php /**PATH D:\wamp\www\cricket\app\Modules/Theme/Views/layouts/success.blade.php ENDPATH**/ ?>