
    <?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">

                    <div class="card">
                        <div class="header">
                            <h4 class="title">Add Players for This Match</h4>
                            <a class="linkClass" href="<?php echo e(route('matchSquads')); ?>">Back to list</a>
                        </div>
                        <div class="content">
                            <form method="post">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" value="<?php echo e($matchSquad->match_id); ?>" name="match_id">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>Match ID : <?php echo e($matchSquad->match_id); ?></label>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label><?php echo e($matchSquad->first_team_name); ?></label>
                                            <!--<input type="text" class="form-control teamA" data-src="teamA" data-team="" placeholder="Match ID" name="playerID" id="match_id">-->
                                            <div id="teamA">
                                                <ul  class="list-group" >
                                                    <?php $__currentLoopData = $firstTeamPlayers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li class="teamlisting list-group-item" id="player1">
                                                            <input  type="checkbox" name="teamA[]" value="<?php echo e($data->pid); ?>" <?php echo e(isset($firstTeamSelectedPlayers[$data->pid]) ? 'checked' : ''); ?>>
                                                            <?php echo e($data->player_name); ?>

                                                        </li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>	
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label><?php echo e($matchSquad->second_team_name); ?></label>
                                            <!--<input type="text" class="form-control teamB" placeholder="Match ID" data-src="teamB" data-team="" name="playerID" id="match_id">-->
                                            <div id="teamB">
                                                <ul class="list-group">
                                                    <?php $__currentLoopData = $secondTeamPlayers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li class="teamlisting list-group-item" id="player2">
                                                            <input type="checkbox" name="teamB[]" value="<?php echo e($data->pid); ?>" <?php echo e(isset($secondTeamSelectedPlayers[$data->pid]) ? 'checked' : ''); ?>>
                                                            <?php echo e($data->player_name); ?>

                                                        </li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>	
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <input type="submit" class="btn btn-info btn-fill pull-right" />
                                <div class="clearfix"></div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
    <?php $__env->startPush('scripts'); ?>
        <script>
            $(function() {
                $('#match_date').datetimepicker({
                    format: 'YYYY-MM-DD'
                });
            });
        </script>
    <?php $__env->stopPush(); ?>
<?php echo $__env->make('Theme::layouts.baseLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nkrjm0cj9ho1/public_html/demo2.pricecheckindia.in/app/Modules/MatchSquad/Views/add.blade.php ENDPATH**/ ?>