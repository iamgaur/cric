<?php if($errors->has('invalid_attempt')): ?>
    <div class="alert alert-warning">
         <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
        <strong><?php echo e($errors->first('invalid_attempt')); ?></strong>
    </div>
<?php endif; ?><?php /**PATH /home/nkrjm0cj9ho1/public_html/demo2.pricecheckindia.in/app/Modules/Login/Views/login/errors.blade.php ENDPATH**/ ?>