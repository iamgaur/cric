<footer class="footer">
	<div class="container-fluid">
		<p class="copyright pull-right">
			&copy; <?php echo e(date('Y')); ?> </p>
	</div>
</footer><?php /**PATH D:\wamp\www\cricket\app\Modules/Theme/Views/layouts/footer.blade.php ENDPATH**/ ?>