    <?php $__env->startSection('content'); ?>
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Galleryes</h4><a class="linkClass" href="<?php echo e(route('addGallery')); ?>">Add new gallery</a>
                            </div>
                            <div class="content table-responsive table-full-width">
                                <table class="table table-hover table-striped">
                                    <thead>
                                        <tr><th>Gallery ID</th>
                                            <th>Item Name</th>
                                            <th>Type</th>
                                            <th>Action</th>
                                        </tr></thead>
                                    <tbody>
                                        
                                        <?php $__currentLoopData = $fetchGallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($value['id']); ?></td>
                                                <td><?php echo e($value['type_name']); ?></td>
                                                <td class="text-uppercase"><?php echo e($galleryTypes[$value['type']]); ?></td>
                                                <td><a href="<?php echo e(route('editGallery', ['id' => $value['id']])); ?>">edit</a> |
                                                    <a href="<?php echo e(route('deleteGallery', ['id' => $value['id']])); ?>" onclick="if (!confirm('are you sure want to delete this gallery?')) return false;" >delete</a></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('Theme::layouts.baseLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp\www\cricket\app\Modules/Gallery/Views/index.blade.php ENDPATH**/ ?>