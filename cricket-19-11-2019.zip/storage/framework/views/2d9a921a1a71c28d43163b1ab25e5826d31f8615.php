    <style>
        .pl-0 {
            padding-left: 0 !important;
        }
        .pr-0 {
            padding-right: 0 !important;
        }
        .modal-backdrop.in {
            display: none !important;
        }
    </style>
    <link href="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.4/summernote.css" rel="stylesheet">
    <?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="header">
                            <h4 class="title"><?php echo e($title); ?></h4>
                            <a class="linkClass" href=" <?php echo e(route('players')); ?>">Back to list</a>
                        </div>
                        <div class="content">
                            <form method="post">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <?php
                                               $national_team = array(
                                                    'team_id' => null,
                                                    'time_from' => null,
                                                    'time_to' => null
                                                );
                                                $j = 1;
                                                $club[1] = array(
                                                                'team_id' => null,
                                                                'time_from' => null,
                                                                'time_to' => null,
                                                            );
                                             
                                            ?>
                                            <?php $__currentLoopData = $playerTeams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $playerTeam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                                <?php
                                                    if ($playerTeam['team_type'] == 1) {
                                                        $national_team = array(
                                                            'team_id' => $playerTeam['team_id'],
                                                            'time_from' => $playerTeam['time_from'],
                                                            'time_to' => $playerTeam['time_to']
                                                        );
                                                    } else {
                                                        $club[$j] = array(
                                                            'team_id' => $playerTeam['team_id'],
                                                            'time_from' => $playerTeam['time_from'],
                                                            'time_to' => $playerTeam['time_to'],
                                                        );
                                                        $j++;
                                                    }
                                                ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                           
                                            <label>National Team</label>
                                            <select name="team_country[team][0][team_id]" id="team_country">
                                                <option value="">Select National Team</option>
                                                <?php if(!empty($nationalTeamList)): ?>
                                               
                                                    <?php $__currentLoopData = $nationalTeamList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option <?php echo e(old('team_country.team.0.team_id', $national_team['team_id']) == $data['id'] ? 'selected' : null); ?> value="<?php echo e($data['id']); ?>"><?php echo e($data['name']); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </select>
                                            <input id="action_id" value="<?php echo e(old('team_country.team.0.start_date', $national_team['time_from'])); ?>" name="team_country[team][0][start_date]" type="text" placeholder="Start Date" required class="form-control input-md pickerDate">
                                            <br />
                                            <input id="action_id" value="<?php echo e(old('team_country.team.0.end_date', $national_team['time_to'])); ?>" name="team_country[team][0][end_date]" type="text" placeholder="End Date"  class="form-control input-md pickerDate">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <div class="">
                                                <div id="field">
                                                    <?php for($i = 1; $i <= count($club); $i++): ?>
                                                    <div class="club-listing" id="field<?php echo e($i); ?>">
                                                        <div class="form-group">
                                                            <label>Club</label>
                                                            <select name="team_country[team][<?php echo e($i); ?>][team_id]" class="team_country_club">
                                                                <option value="">Select Club</option>
                                                                <?php if(!($clubTeamList->isEmpty())): ?>
                                                                    <?php $__currentLoopData = $clubTeamList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option <?php echo e(old( 'team_country.team.' . $i . '.team_id', $club[$i]['team_id']) == $data['id'] ? 'selected' : null); ?> value="<?php echo e($data['id']); ?>"><?php echo e($data['name']); ?></option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                <?php endif; ?>
                                                            </select>
                                                        </div>
                                                        <!-- Text input-->
                                                        <div class="form-group">
                                                            <div class="">
                                                                <input value="<?php echo e(old('team_country.team.1.start_date', $club[$i]['time_from'])); ?>" name="team_country[team][<?php echo e($i); ?>][start_date]" type="text" placeholder="Start Date" class="form-control input-md pickerDate">
                                                            </div>
                                                        </div>
                                                        <!-- Text input-->
                                                        <div class="form-group">
                                                            <div class="">
                                                                <input  value="<?php echo e(old('team_country.team.1.start_date', $club[$i]['time_to'])); ?>" name="team_country[team][<?php echo e($i); ?>][end_date]" type="text" placeholder="End Date" class="form-control input-md pickerDate">
                                                            </div>
                                                        </div>
                                                        <!--Button-->
                                                        <div class="form-group">
                                                            <div class="">
                                                                <button id="add-more" name="add-more" class="btn btn-primary">Add More</button>
                                                                <button class="btn btn-danger remove-me <?php echo e($i > 1 ? null : 'hidden'); ?>">Remove</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <?php endfor; ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>Name</label>
                                            <input type="text" value="<?php echo e(old('player_name', $player->player_name)); ?>" class="form-control" placeholder="Player name" name="player_name" id="player_name">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>Born</label>
                                            <input type="text" value="<?php echo e(old('player_born', $player->player_born)); ?>" class="form-control pickerDate" placeholder="Date of birth" name="player_born" id="player_dob">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>Also known as</label>
                                            <input type="text" value="<?php echo e(old('player_nickname', $player->player_nickname)); ?>" class="form-control" placeholder="Also known as" name="player_nickname" id="player_nickname">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>Playing role</label>
                                            <input type="text" value="<?php echo e(old('player_playing_role', $player->player_playing_role)); ?>" class="form-control" placeholder="Playing role" name="player_playing_role" id="player_playing_role">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>Batting style</label>
                                            <input type="text"  value="<?php echo e(old('player_playing_batting', $player->player_playing_batting)); ?>" class="form-control" placeholder="Batting style" name="player_playing_batting" id="player_batting_style">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>Bowling style</label>
                                            <input type="text" value="<?php echo e(old('player_playing_bowling', $player->player_playing_bowling)); ?>" class="form-control" placeholder="Bowling style" name="player_playing_bowling" id="player_bowling_style">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>Fielding position</label>
                                            <input type="text"  value="<?php echo e(old('player_fielding_position', $player->player_fielding_position)); ?>" class="form-control" placeholder="Fielding position" name="player_fielding_position" id="player_fielding_position">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>Bio</label>
                                            <textarea rows="5"  name="player_bio" class="form-control" placeholder="Here can be your description" value="Mike" id="editor"><?php echo e(old('player_bio', $player->player_bio)); ?></textarea>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>Meta title</label>
                                            <input type="text"  value="<?php echo e(old('meta_title', $player->meta_title)); ?>" class="form-control" placeholder="Meta title" name="meta_title" id="meta_title">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>Meta description</label>
                                            <input type="text"  value="<?php echo e(old('meta_description', $player->meta_description)); ?>" class="form-control" placeholder="Meta description" name="meta_description" id="meta_description">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>Meta keywords</label>
                                            <input type="text"  value="<?php echo e(old('meta_keywords', $player->meta_keywords)); ?>" class="form-control" placeholder="Meta keywords" name="meta_keywords" id="meta_keywords">
                                        </div>
                                    </div>
                                </div>

                                <?php $__currentLoopData = $group_fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $heading => $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                    <div class="group-field">
                                        <div class="heading">
                                            <h3><?php echo e($heading); ?></h3>
                                            <input type="hidden" value="<?php echo e($group['heading']); ?>" name="group[<?php echo e($group['heading']); ?>][heading]">
                                            <div class="sub-field">
                                                <?php $__currentLoopData = $group['fields']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $title => $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div style="margin-bottom: 45px;" class="sub-field-title">
                                                        <label><strong><?php echo e($title); ?></strong></label>
                                                        <input class="col-md-12" type="text" value="<?php echo e($field); ?>" name="group[<?php echo e($group['heading']); ?>][fields][<?php echo e($title); ?>]">
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                
                                <input type="submit" class="btn btn-info btn-fill pull-right" />
                                <div class="clearfix"></div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
    <?php $__env->startPush('scripts'); ?>
        <script src="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.4/summernote.js"></script>
        <script type="text/javascript">  
            $(document).ready(function () {
                $(document.body).on('click', '#add-more',function(e){
                    e.preventDefault();
                    var current = $('.club-listing').length;
                    var next = (parseInt(current)+1);
                    var field = $('#field1').clone();
                    field.prop('id', 'field' + next);

                    field.find('[name="team_country[team][1][team_id]"]').val('');
                    field.find('[name="team_country[team][1][team_id]"]').attr('name', "team_country[team]["+ next +"][team_id]");
                    field.find('[name="team_country[team][1][start_date]"]').val('');
                    field.find('[name="team_country[team][1][start_date]"]').attr('name', "team_country[team]["+ next +"][start_date]");
                    field.find('[name="team_country[team][1][end_date]"]').val('');
                    field.find('[name="team_country[team][1][end_date]"]').attr('name', "team_country[team]["+ next +"][end_date]");
                    field.find('.remove-me').removeClass('hidden');
                    field.appendTo('#field');
                    $('.pickerDate').data('DateTimePicker').destroy();
                    $('.club-listing').each(function() {
                        $('.pickerDate').datetimepicker({
                            widgetParent: $(this),
                            format: 'YYYY-MM-DD'
                        }); 
                    });
                });
                $(document.body).on('click', '.remove-me', function(e){
                    e.preventDefault();
                    $(this).parents('.club-listing').remove();
                });
                $('.pickerDate').datetimepicker({
                    format: 'YYYY-MM-DD'
                }); 
                $('#editor').summernote({
                  height: 500,
                });
            });
        </script>
    <?php $__env->stopPush(); ?>

<?php echo $__env->make('Theme::layouts.baseLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nkrjm0cj9ho1/public_html/demo2.pricecheckindia.in/app/Modules/Player/Views/add.blade.php ENDPATH**/ ?>