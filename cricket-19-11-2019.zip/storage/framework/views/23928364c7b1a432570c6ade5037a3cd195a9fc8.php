    <?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="header">
                            <h4 class="title"><?php echo e($title); ?></h4>
                            <a class="linkClass" href=" <?php echo e(route('teams')); ?>">Back to list</a>
                        </div>
                        <div class="content">
                            <form method="post">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>Name</label>
                                            <input type="text" class="form-control" placeholder="Team name" value="<?php echo e(old('name', $team->name)); ?>" name="name" id="team_name">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>Short name</label>
                                            <input type="text" class="form-control" placeholder="Short name" value="<?php echo e(old('short_name', $team->short_name)); ?>" name="short_name" id="short_name">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>Country</label>
                                            <select class="form-control" name="country_id" id="team_country">
                                                <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country_id => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                   <option <?php echo e(old('country_id', $team->country_id) == $country_id ? 'selected' : null); ?> value="<?php echo e($country_id); ?>"><?php echo e($name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>Type</label>
                                            <select class="form-control" name="team_type" id="team_type">
                                                <option <?php echo e(old('team_type', $team->team_type) == 1 ? 'selected' : null); ?> value="1"><?php echo e(config('constants.team_type.1')); ?></option>
                                                <option <?php echo e(old('team_type', $team->team_type) == 2 ? 'selected' : null); ?> value="2"><?php echo e(config('constants.team_type.2')); ?></option>
                                                <option <?php echo e(old('team_type', $team->team_type) == 3 ? 'selected' : null); ?> value="3"><?php echo e(config('constants.team_type.3')); ?></option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>Meta title</label>
                                            <input type="text" class="form-control" placeholder="Meta title" name="meta_title" value="<?php echo e(old('meta_title', $team->meta_title)); ?>" id="meta_title">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>Meta description</label>
                                            <input type="text" class="form-control" placeholder="Meta description" name="meta_description" value="<?php echo e(old('meta_description', $team->meta_description)); ?>" id="meta_description">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>Meta keywords</label>
                                            <input type="text" class="form-control" placeholder="Meta keywords" name="meta_keywords" value="<?php echo e(old('meta_keywords', $team->meta_keywords)); ?>" id="meta_keywords">
                                        </div>
                                    </div>
                                </div>
                                <input type="submit" class="btn btn-info btn-fill pull-right" />
                                <div class="clearfix"></div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('Theme::layouts.baseLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp\www\cricket\app\Modules/Team/Views/add.blade.php ENDPATH**/ ?>