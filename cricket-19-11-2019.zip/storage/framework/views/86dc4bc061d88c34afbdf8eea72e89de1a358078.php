    <?php $__env->startSection('content'); ?>
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Series</h4><a class="linkClass" href="<?php echo e(route('addSeries')); ?>">Add new series</a>
                            </div>
                            <div class="content table-responsive table-full-width">
                                <table class="table table-hover table-striped">
                                    <thead>
                                        <tr><th>ID</th>
                                            <th>Name</th>
                                            <th>Start date</th>
                                            <th>End date</th>
                                            <th>Action</th>
                                        </tr></thead>
                                    <tbody>
                                        <?php $__currentLoopData = $fetchSeries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($value['id']); ?></td>
                                                <td><?php echo e($value['name']); ?></td>
                                                <td><?php echo e(date('Y-m-d', strtotime($value['series_start_date']))); ?></td>
                                                <td><?php echo e(date('Y-m-d', strtotime($value['series_end_date']))); ?></td>
                                                <td><a href="<?php echo e(route('editSeries', ['slug' => $value['slug'] ])); ?>">edit</a> |
                                                  <a href="<?php echo e(route('pointTable', ['slug' => $value['slug'] ])); ?>">Add Points</a> |
                                                     <a href="<?php echo e(route('deleteSeries', ['slug' => $value['slug']])); ?>" onclick="if (!confirm('are you sure want to delete this series?')) return false;" >delete</a></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('Theme::layouts.baseLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nkrjm0cj9ho1/public_html/demo2.pricecheckindia.in/app/Modules/Series/Views/index.blade.php ENDPATH**/ ?>