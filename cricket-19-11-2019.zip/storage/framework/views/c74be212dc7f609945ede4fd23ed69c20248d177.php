<?php if($errors->has('invalid_attempt')): ?>
    <div class="alert alert-warning">
         <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
        <strong><?php echo e($errors->first('invalid_attempt')); ?></strong>
    </div>
<?php endif; ?><?php /**PATH D:\wamp\www\cricket\app\Modules/Login/Views/login/errors.blade.php ENDPATH**/ ?>