<?php if(session()->has('success')): ?>
    <div class="col-xl-12 col-md-12 alert alert-success alert-dismissible">
      <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
       <strong><?php echo e(session()->get('success')); ?></strong>
    </div>
<?php endif; ?><?php /**PATH /home/nkrjm0cj9ho1/public_html/demo2.pricecheckindia.in/app/Modules/Theme/Views/layouts/success.blade.php ENDPATH**/ ?>