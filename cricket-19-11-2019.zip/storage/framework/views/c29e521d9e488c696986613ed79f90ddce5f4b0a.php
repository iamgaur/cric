<?php
    $currentRouteName = strlen(Route::currentRouteName()) ? Route::currentRouteName() : null;
?>

<ul class="nav">
	<li class="<?php echo e(($currentRouteName == 'dashboard') ? 'active' : ''); ?>">
		<a href="<?php echo e(route('dashboard')); ?>">
			<i class="pe-7s-graph"></i>
			<p>Dashboard</p>
		</a>
	</li>
	<li class="<?php echo e(($currentRouteName == 'countries') ? 'active' : ''); ?>">
		<a href="<?php echo e(route('countries')); ?>">
			<p>Country</p>
		</a>
	</li>
	<li class="<?php echo e(($currentRouteName == 'teams') ? 'active' : ''); ?>">
		<a href="<?php echo e(route('teams')); ?>">
			<p>Team</p>
		</a>
	</li>
	<li class="<?php echo e(($currentRouteName == 'series') ? 'active' : ''); ?>">
		<a href="<?php echo e(route('series')); ?>">
			<p>Series</p>
		</a>
	</li>
	<li class="<?php echo e(($currentRouteName == 'matches') ? 'active' : ''); ?>">
		<a href="<?php echo e(route('matches')); ?>">
			<p>Match</p>
		</a>
	</li>
        <li class="<?php echo e(($currentRouteName == 'matchTeams') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('matchTeams')); ?>">
                <p>Match -- Teams</p>
            </a>
        </li>
        <li class="<?php echo e(($currentRouteName == 'matchSquads') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('matchSquads')); ?>">
                <p>Match -- Squad</p>
            </a>
        </li>
	<li class="<?php echo e(($currentRouteName == 'players') ? 'active' : ''); ?>">
		<a href="<?php echo e(route('players')); ?>">
			<p>Player</p>
		</a>
	</li>
	<li class="<?php echo e(($currentRouteName == 'news') ? 'active' : ''); ?>">
		<a href="<?php echo e(route('news')); ?>">
			<p>News</p>
		</a>
	</li>
	<li class="<?php echo e(($currentRouteName == 'gallery') ? 'active' : ''); ?>">
		<a href="<?php echo e(route('gallery')); ?>">
			<p>Gallery</p>
		</a>
	</li>
	<li class="<?php echo e(($currentRouteName == 'logout') ? 'active' : ''); ?>">
		<a href="<?php echo e(route('logout')); ?>">
			<p>Logout</p>
		</a>
	</li>

</ul><?php /**PATH D:\wamp\www\cricket\app\Modules/Theme/Views/layouts/menu.blade.php ENDPATH**/ ?>