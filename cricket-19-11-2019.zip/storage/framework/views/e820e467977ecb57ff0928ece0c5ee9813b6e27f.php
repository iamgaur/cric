<style>
    .repeat-group {
        width: 100%;
        float: left;
    }

    </style>
<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="header">
                        <h4 class="title"><?php echo e($title); ?></h4>
                        <a class="linkClass" href=" <?php echo e(route('players')); ?>">Back to list</a>
                    </div>
                    <div class="content">
                        <form method="post" action="<?php echo e(route('addGroupFields')); ?>">

                            <?php echo csrf_field(); ?>
                            <?php $i = 1; ?>
                            <div class="group-fields-clone  <?php echo e(count($field_group) > 0 ? 'hidden': 'repeat-group'); ?>">
                                <span class="number"><?php echo e($i); ?>.</span> 
                                <label>Heading</label>
                                <div class="form-inline">
                                    <input type="text" style="min-width: 65%;" value="" class="form-control group-field-heading" placeholder="Heading" name="groupField[<?php echo e($i + 1); ?>][heading]">
                                    <button class="btn btn-fill add-more-group">Add More Group</button>
                                    <button class="btn btn-danger remove-group">Remove Group</button>
                                </div>
                                <div class="sub-field-group">
                                    <div class="col-md-12">
                                        <div class="form-group sub-field">
                                            <label>Sub Field Title</label>
                                            <div data-heading-number="<?php echo e($i); ?>" class="form-inline col-md-12 add-more-field">
                                                <span class="single-field" style="display: block; margin-bottom: 5px">
                                                    <input style="min-width: 65%;" type="text" value="" class="form-control group-sub-field-title" placeholder="Field" name="groupField[<?php echo e($i+1); ?>][fields][0]">
                                                    <button class="btn btn-fill add-more">Add More</button>
                                                    <button class="btn btn-danger remove-field">Remove Field</button>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class=" group-fields">
                                <?php $__currentLoopData = $field_group; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="repeat-group">
                                    
                                    <span class="number"><?php echo e($i); ?>.</span>
                                    <label>Heading</label>
                                    <div class="form-inline">
                                        <input type="text" style="min-width: 65%;"  value="<?php echo e($group['heading']); ?>" class="form-control group-field-heading" placeholder="Heading" name="groupField[<?php echo e($i); ?>][heading]">
                                        <button class="btn btn-fill add-more-group">Add More Group</button>
                                        <button class="btn btn-danger remove-group">Remove Group</button>
                                    </div>
                                    
                                   
                                    <div class="sub-field-group">
                                        <div class="col-md-12">
                                            
                                                <div class="form-group sub-field">
                                                    <label>Title</label>
                                                    <div data-heading-number="<?php echo e($i); ?>" class="form-inline col-md-12 add-more-field">
                                                    <?php $j = 0; ?>
                                                    <?php $__currentLoopData = $group['fields']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>     
                                                        <span  class="single-field" style="display: block; margin-bottom: 5px">
                                                            <input type="text" value="<?php echo e($field); ?>" style="min-width: 65%;" class="form-control group-sub-field-title" placeholder="Field" name="groupField[<?php echo e($i); ?>][fields][<?php echo e($j); ?>]" >
                                                            <button class="btn btn-fill add-more">Add More</button>
                                                            <button class="btn btn-danger remove-field">Remove Field</button>
                                                        </span>
                                                        
                                                    <?php $j++; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                </div>
                                            

                                        </div>
                                    </div>
                                </div>
                                <?php $i++; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>      
                            </div>
                            


                            <input type="submit" class="btn btn-info btn-fill pull-right" />
                            <div class="clearfix"></div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script>
    $(function () {
        $(document.body).on('click', '.add-more-group', function (e) {
            e.preventDefault();
            var cloned_dynamic_field = $('.group-fields-clone').clone();

            cloned_dynamic_field.removeClass('group-fields-clone hidden').addClass('repeat-group');
            var next_dynamic_field_number = parseInt($('.repeat-group').length) + 1;
            cloned_dynamic_field.find('.group-field-heading').attr('name', 'groupField[' + next_dynamic_field_number + '][heading]');
            cloned_dynamic_field.find('.number').html(next_dynamic_field_number);
            cloned_dynamic_field.find('.single-field:gt(0)').remove();
            cloned_dynamic_field.find('.group-sub-field-title').attr('name', 'groupField[' + next_dynamic_field_number + '][fields][0]');
            cloned_dynamic_field.find('.add-more-field').attr('data-heading-number', next_dynamic_field_number);
            cloned_dynamic_field.appendTo('.group-fields');
        });
        $(document.body).on('click', '.add-more', function (e) {
            e.preventDefault();
            var cloned = $(this).parents('.single-field').clone();

            var next_dynamic_heading_number = parseInt($(this).parents('.add-more-field').attr('data-heading-number'));
            var next_dynamic_title_number = parseInt($(this).parents('.add-more-field').children('.single-field').length);
            cloned.find('.group-sub-field-title').attr('name', 'groupField['+ next_dynamic_heading_number +'][fields]['+ next_dynamic_title_number +']');
            
            cloned.appendTo($(this).closest('.add-more-field'));
        });

        $(document.body).on('click', '.remove-group', function (e) {
            e.preventDefault();
            if (confirm('Are you sure want to delete this group')) {
                $(this).parents('.repeat-group').remove();
            }
        });

        $(document.body).on('click', '.remove-field', function (e) {
            e.preventDefault();
            if (confirm('Are you sure want to delete this field')) {
                $(this).parents('.single-field').remove();
            }
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('Theme::layouts.baseLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nkrjm0cj9ho1/public_html/demo2.pricecheckindia.in/app/Modules/Player/Views/groupField.blade.php ENDPATH**/ ?>