    <?php $__env->startSection('content'); ?> 
    <style>
        #radioBtn .notActive{
            color: #3276b1;
            background-color: #fff;
        }
    </style>
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">ICC Rankings</h4><a class="linkClass" href="<?php echo e(route('addIccRanking')); ?>">Add new ICC Ranking</a>
                            </div>
                        </div>
                    </div>
                </div>
               
                <div class="row">
                    <div class="col-md-12">
                        <label class="radio-inline"><input type="radio" name="gender_type" value="man" checked>Men</label>
                        <label class="radio-inline"><input type="radio" name="gender_type" value="woman" >Women</label>
                    </div>
                </div>
                <?php $secondhidden = ''; ?>
                <?php $__currentLoopData = config('constants.gender'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gender): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="<?php echo e($gender .' '. $secondhidden); ?> ">
                    <div class="row">
                        <?php $secondhidden = 'hidden'; ?>
                        <div class="col-md-12">
                            <div class="card">
                                <div class="header">
                                    <h4 class="title"><?php echo e($gender == 'man' ? 'Men\'s': 'Women\'s'); ?> Team</h4>
                                </div>

                                <div id="exTab1" class="container">	
                                    <ul  class="nav nav-pills">
                                        <li class="active col-md-3">
                                            <a  href="#t20_rating_<?php echo e($gender); ?>" data-toggle="tab">T20</a>
                                        </li>
                                        <li class="col-md-3"><a href="#odi_rating_<?php echo e($gender); ?>" data-toggle="tab">ODI</a>
                                        </li>
                                        <li class="col-md-3"><a href="#test_rating_<?php echo e($gender); ?>" data-toggle="tab">Test</a>
                                        </li>
                                    </ul>

                                    <div class="tab-content clearfix">
                                        <?php $firstActive = 'active'; ?>
                                        <?php $__currentLoopData = $fetchIccRankings[$gender]['team']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="tab-pane <?php echo e($firstActive); ?>" id="<?php echo e($key. '_' . $gender); ?>">
                                            <div class="content table-responsive table-full-width " id="nav-team-t20" role="tabpanel" aria-labelledby="nav-team-t20">
                                                <table class="table table-hover table-striped">
                                                    <thead>
                                                        <tr>
                                                            <th>Icc Ranking position</th>
                                                            <th>Name</th>
                                                            <th>Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $i = 1; ?>
                                                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td><?php echo e($i++); ?></td>
                                                            <td><?php echo e($allTeam[$value['item_id']]); ?></td>
                                                            <td><a href="<?php echo e(route('editIccRanking', ['id' => $value['id']])); ?>">edit</a> |
                                                                <a href="<?php echo e(route('deleteIccRanking', ['id' => $value['id']])); ?>" onclick="if (!confirm('are you sure want to delete this Ranking?')) return false;" >delete</a></td>
                                                        </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                        <?php $firstActive = null; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="header">
                                    <h4 class="title"><?php echo e($gender == 'man' ? 'Men\'s': 'Women\'s'); ?> Players</h4>
                                </div>

                                <div id="exTab2" class="container">	
                                        <ul  class="nav nav-pills">
                                            <li class="active col-md-3">
                                                <a  href="#t20_player_<?php echo e($gender); ?>" data-toggle="tab">T20</a>
                                            </li>
                                            <li class="col-md-3"><a href="#odi_player_<?php echo e($gender); ?>" data-toggle="tab">ODI</a>
                                            </li>
                                            <li class="col-md-3"><a href="#test_player_<?php echo e($gender); ?>" data-toggle="tab">Test</a>
                                            </li>
                                        </ul>

                                        <div class="tab-content clearfix">
                                            <?php $firstActive = 'active'; ?>
                                            <?php $__currentLoopData = $fetchIccRankings[$gender]['player']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="tab-pane <?php echo e($firstActive); ?>" id="<?php echo e($key . '_' . $gender); ?>">
                                                    <ul  class="nav nav-pills">
                                                        <li class="active col-md-3">
                                                            <a  href="#<?php echo e($gender.$key); ?>batting_rating" data-toggle="tab">Batting</a>
                                                        </li>
                                                        <li class="col-md-3"><a href="#<?php echo e($gender.$key); ?>bowling_rating" data-toggle="tab">Bowling</a>
                                                        </li>
                                                        <li class="col-md-3"><a href="#<?php echo e($gender.$key); ?>all_rounder_rating" data-toggle="tab">All Rounder</a>
                                                        </li>
                                                    </ul>

                                                    <div class="tab-content clearfix">
                                                        <?php $firstSubActive = 'active'; ?>
                                                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keyCategory => $subCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="tab-pane <?php echo e($firstSubActive); ?>" id="<?php echo e($gender.$key); ?><?php echo e($keyCategory); ?>">
                                                                <div class="content table-responsive table-full-width " id="nav-team-t20" role="tabpanel" aria-labelledby="nav-team-t20">
                                                                    <table class="table table-hover table-striped">
                                                                        <thead>
                                                                            <tr>
                                                                                <th>Icc Ranking position</th>
                                                                                <th>Name</th>
                                                                                <th>Action</th>
                                                                            </tr>
                                                                        </thead>
                                                                        <tbody>
                                                                            <?php $i = 1; ?>
                                                                            <?php $__currentLoopData = $subCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCategoryValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                <?php
                                                                                $value = $subCategoryValue->toArray();    
                                                                                ?>
                                                                                <tr>
                                                                                    <td><?php echo e($i++); ?></td>
                                                                                    <td><?php echo e($allPlayer[$value['item_id']]); ?></td>
                                                                                    <td><a href="<?php echo e(route('editIccRanking', ['id' => $value['id']])); ?>">edit</a> |
                                                                                        <a href="<?php echo e(route('deleteIccRanking', ['id' => $value['id']])); ?>" onclick="if (!confirm('are you sure want to delete this Ranking?')) return false;" >delete</a></td>
                                                                                </tr>
                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                        </tbody>
                                                                    </table>
                                                                </div>
                                                            </div>
                                                        <?php $firstSubActive = null; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                </div>
                                            <?php $firstActive = null; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </div>
                                    </div>
                            </div>
                        </div>

                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php $__env->stopSection(); ?>
    <?php $__env->startPush('scripts'); ?>
    <script>
        $(function() {
            $('[name="gender_type"]').change(function() {
               $('.woman').addClass('hidden');
               $('.man').addClass('hidden');
               $('.' + $(this).val()).removeClass('hidden');
            });
        });
    </script>
    <?php $__env->stopPush(); ?>

<?php echo $__env->make('Theme::layouts.baseLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nkrjm0cj9ho1/public_html/demo2.pricecheckindia.in/app/Modules/IccRanking/Views/index.blade.php ENDPATH**/ ?>